#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
themes=/usr/share/sddm/themes
name=43pr-astronaut
source_theme=$themes/sddm-astronaut-theme
stage=$(mktemp -d)
trap 'rm -rf -- "$stage"' EXIT

cp -a "$source_theme/." "$stage/"
patch --batch --forward -d "$stage" -p0 < "$here/astronaut.patch"
install -m 644 "$here/LoginTransition.qml" "$stage/Components/LoginTransition.qml"
sed -i "s/^Name=.*/Name=$name/; s/^Theme-Id=.*/Theme-Id=$name/" "$stage/metadata.desktop"

if [[ ${1:-} == --preview ]]; then
    sddm-greeter-qt6 --test-mode --theme "$stage"
    exit
fi

if [[ $(id -u) == 0 ]]; then
    printf '%s\n' 'Run this script from your desktop account. It will request sudo for the system files.' >&2
    exit 1
fi

sudo -v
sudo install -d -m 0755 -o "$(id -u)" -g "$(id -g)" /var/lib/43pr-sddm
bash "$here/../configs/hypr/scripts/sddm-wallpaper.sh"

sudo install -d -m 0755 "$themes/$name"
sudo cp -r --no-preserve=ownership "$stage/." "$themes/$name/"
printf '[Theme]\nCurrent=%s\n' "$name" > "$stage/sddm.conf"
sudo install -m 0644 "$stage/sddm.conf" /etc/sddm.conf.d/zz-43pr-astronaut.conf
printf '%s\n' '43PR Astronaut will load the next time SDDM starts.'
