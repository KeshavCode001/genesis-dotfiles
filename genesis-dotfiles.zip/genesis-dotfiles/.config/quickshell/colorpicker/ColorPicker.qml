import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import ".."
import "ColorUtil.js" as CU

// Runs inside the main shell (uses the single quickshell/Theme.qml).
// Trigger with:  qs ipc call colorpicker start   (or toggle)
Scope {
    id: root

    // ───────── Configuration ─────────
    // Selectable actions for each mouse button (persisted in the history file)
    readonly property var actions: [
        { id: "copy-edit",  label: "Copy + edit" },
        { id: "copy-close", label: "Copy" },
        { id: "cancel",     label: "Cancel" }
    ]
    readonly property string leftClick: hist.left
    readonly property string middleClick: hist.middle
    readonly property string rightClick: hist.right
    readonly property bool actionsHidden: hist.actionsHidden
    readonly property string hintText:
        "LMB " + actionLabel(leftClick).toLowerCase()
        + "  ·  MMB " + actionLabel(middleClick).toLowerCase()
        + "  ·  RMB " + actionLabel(rightClick).toLowerCase()
    readonly property int historyLimit: 20
    property string copyFormat: "hex"          // hex | rgb | hsl  (Tab cycles while picking)

    // ───────── State ─────────
    property string mode: "idle"               // idle | capturing | picking | editing
    property var picked: ({ r: 0, g: 0, b: 0 })
    property string curScreen: ""
    property string focusScreen: ""
    property real mx: 0
    property real my: 0
    property int zoomIndex: 3
    readonly property var zoomLevels: [41, 31, 21, 15, 11, 9, 7, 5]   // source pixels across the loupe
    readonly property var history: hist.items

    // ───────── Triggers ─────────
    GlobalShortcut {
        appid: "colorpicker"
        name: "pick"
        description: "Start the color picker"
        onPressed: root.start()
    }
    IpcHandler {
        target: "colorpicker"
        function toggle(): void { root.mode === "idle" ? root.start() : root.stop(); }
        function start(): void { root.start(); }
    }

    // ───────── Logic ─────────
    function screenByName(n) {
        for (var i = 0; i < Quickshell.screens.length; i++)
            if (Quickshell.screens[i].name === n) return Quickshell.screens[i];
        return Quickshell.screens[0];
    }

    function start() {
        if (mode !== "idle") return;
        var fm = Hyprland.focusedMonitor;
        focusScreen = curScreen = fm ? fm.name : Quickshell.screens[0].name;
        var cmds = [];
        for (var i = 0; i < Quickshell.screens.length; i++) {
            var n = Quickshell.screens[i].name;
            cmds.push("grim -l 0 -o '" + n + "' '/tmp/qs-colorpicker-" + n + ".png'");
        }
        capture.command = ["sh", "-c", cmds.join(" & ") + " & wait"];
        mode = "capturing";
        capture.running = true;
    }

    // Close the picker (the shell keeps running)
    function stop() { mode = "idle"; }

    // Restart a pick
    function again() { mode = "idle"; start(); }

    function copyText(t) { Quickshell.execDetached(["wl-copy", t]); }

    function act(kind) {
        if (kind === "cancel") { stop(); return; }
        copyText(CU.format(picked, copyFormat));
        pushHistory(CU.hex(picked));
        if (kind === "copy-edit") mode = "editing"; else stop();
    }

    function pushHistory(h) {
        var a = [h];
        for (var i = 0; i < hist.items.length && a.length < historyLimit; i++)
            if (hist.items[i] !== h) a.push(hist.items[i]);
        hist.items = a;
        store.writeAdapter();
    }

    function clearHistory() { hist.items = []; store.writeAdapter(); }
    function actionLabel(id) {
        for (var i = 0; i < actions.length; i++)
            if (actions[i].id === id) return actions[i].label;
        return id;
    }

    function toggleActionsHidden() { hist.actionsHidden = !hist.actionsHidden; store.writeAdapter(); }

    // button: "left" | "middle" | "right"
    function setAction(button, id) {
        if (button === "left") hist.left = id;
        else if (button === "middle") hist.middle = id;
        else hist.right = id;
        store.writeAdapter();
    }

    function zoomIn()  { zoomIndex = Math.min(zoomLevels.length - 1, zoomIndex + 1); }
    function zoomOut() { zoomIndex = Math.max(0, zoomIndex - 1); }
    function cycleFormat() {
        var f = ["hex", "rgb", "hsl"];
        copyFormat = f[(f.indexOf(copyFormat) + 1) % 3];
    }

    // Move the real pointer by (dx, dy) logical pixels (keyboard fine-positioning)
    function nudge(dx, dy) {
        var s = screenByName(curScreen);
        var nx = Math.max(0, Math.min(s.width - 1, Math.floor(mx) + dx));
        var ny = Math.max(0, Math.min(s.height - 1, Math.floor(my) + dy));
        mx = nx;
        my = ny;
        Quickshell.execDetached(["hyprctl", "dispatch",
            "hl.dsp.cursor.move({ x = " + Math.round(s.x + nx) + ", y = " + Math.round(s.y + ny) + " })"]);
    }

    // ───────── Plumbing ─────────
    Process {
        id: capture
        onExited: (code, status) => {
            if (code === 0) root.mode = "picking";
            else {
                Quickshell.execDetached(["notify-send", "Color Picker", "Screen capture failed (is grim installed?)"]);
                root.stop();
            }
        }
    }

    FileView {
        id: store
        path: Quickshell.statePath("colorpicker-history.json")
        blockLoading: true
        blockWrites: true
        atomicWrites: true
        onLoadFailed: error => writeAdapter()
        adapter: JsonAdapter {
            id: hist
            property list<string> items: []
            property string left: "copy-edit"
            property string middle: "copy-close"
            property string right: "cancel"
            property bool actionsHidden: false
        }
    }

    Variants {
        model: Quickshell.screens
        ColorPickerOverlay {
            required property var modelData
            screen: modelData
            ctl: root
        }
    }

    ColorPickerEditor { ctl: root }
}