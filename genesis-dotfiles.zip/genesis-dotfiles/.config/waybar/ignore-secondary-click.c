#include <gtk/gtk.h>

static void dispatch_event(GdkEvent *event, gpointer data)
{
    guint button;

    (void)data;
    if (gdk_event_get_button(event, &button) && button == GDK_BUTTON_SECONDARY)
        return;

    gtk_main_do_event(event);
}

G_MODULE_EXPORT void gtk_module_init(gint *argc, gchar ***argv)
{
    (void)argc;
    (void)argv;
    if (g_strcmp0(g_get_prgname(), "waybar") == 0)
        gdk_event_handler_set(dispatch_event, NULL, NULL);
}
