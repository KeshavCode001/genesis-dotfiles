pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Mpris

Scope {
    id: root
    property var levels: []
    readonly property var player: Mpris.players.values.find(p => p.isPlaying) ?? Mpris.players.values[0] ?? null

    Process {
        running: root.player?.isPlaying ?? false
        command: ["/usr/bin/cava", "-p", Quickshell.shellPath("cava.conf")]
        stdout: SplitParser {
            onRead: line => {
                const levels = line.split(";").slice(0, 10).map(value => Number(value) / 100);
                if (levels.length === 10 && levels.every(Number.isFinite)) root.levels = levels;
            }
        }
        onRunningChanged: if (!running) root.levels = []
    }
}
