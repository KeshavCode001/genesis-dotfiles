# Optional SDDM greeter

This patch targets the Astronaut theme with its `Themes/hyprland_kath.conf` profile. It creates a separate 43PR variant. The in-session lock screen works independently.

Preview from the repository root with `bash sddm/install.sh --preview`. If the installer reports a patch mismatch, check that your installed Astronaut theme matches the expected files and profile before activating.

Run `bash sddm/install.sh` from your desktop account to install the variant. It requests sudo for the system files. The next SDDM start uses the new theme. Wallpaper changes made through the 43PR picker publish a copy to `/var/lib/43pr-sddm/wallpaper.jpg` for the greeter. The submission animation plays before SDDM authenticates.

To switch back to the original greeter, remove `/etc/sddm.conf.d/zz-43pr-astronaut.conf` and restart SDDM at your next logout or reboot.
