// 43PR entrypoint for Pocket Dots' notch and its optional panels.
import Quickshell
import QtQuick

Scope {
    id: root
    property var notificationSource
    Binding { target: ShellState; property: "notificationSource"; value: root.notificationSource }
    Component.onDestruction: ShellState.closePanel()
    TopShell {}
    StageWindow {}
    SettingsWindow {}
}
