import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower

FocusScope {
    id: scene
    required property bool checking
    required property string message
    property bool unlocking: false
    signal submitted(string password)
    signal unlockAnimationFinished()

    property real seconds: 0
    property string openPanel: ""
    property string calendarReturn: ""
    property real unlockFade: 1
    readonly property bool dashboard: openPanel === "dashboard"
    readonly property real dashboardCenterY: height * 0.35
    readonly property real centerX: width / 2
    readonly property real centerY: height * 0.49
    readonly property real unit: Math.min(1.45, height / 840, width / 760)
    readonly property real phase: seconds * Math.PI * 2 / 150 - Math.PI / 2
    readonly property var player: Spectrum.player
    readonly property var battery: UPower.devices.values.find(device => device.isLaptopBattery) ?? null
    readonly property string cache: (Quickshell.env("XDG_CACHE_HOME") || Quickshell.env("HOME") + "/.cache") + "/43pr"
    property var notificationGroups: []

    FileView {
        path: scene.cache + "/notifications.json"
        printErrors: false
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            try {
                const groups = new Map();
                for (const item of JSON.parse(text())) {
                    if (item.appName) groups.set(item.appName, (groups.get(item.appName) ?? 0) + 1);
                }
                scene.notificationGroups = Array.from(groups, ([name, count]) => ({ name, count })).slice(0, 3);
            } catch (error) {
                scene.notificationGroups = [];
            }
        }
    }

    component LockText: Text { font.family: Theme.font.family }

    function togglePanel(name) {
        if (unlocking) return;
        if (name === "calendar" && openPanel !== "calendar")
            calendarReturn = dashboard ? "dashboard" : "";
        if (openPanel === name)
            openPanel = name === "calendar" ? calendarReturn : "";
        else
            openPanel = name;
        if (dashboard) Qt.callLater(() => password.forceActiveFocus());
        else scene.forceActiveFocus();
    }

    focus: true
    Keys.onEscapePressed: if (scene.openPanel !== "") scene.togglePanel(scene.openPanel)
    Keys.onPressed: event => {
        if (scene.unlocking || scene.dashboard || event.key === Qt.Key_Escape) return;
        const modified = event.modifiers & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier);
        if (modified || !event.text || event.text.charCodeAt(0) < 32) return;
        scene.openPanel = "dashboard";
        password.forceActiveFocus();
        password.insert(password.cursorPosition, event.text);
        event.accepted = true;
    }

    SequentialAnimation {
        running: scene.unlocking
        onFinished: scene.unlockAnimationFinished()
        PauseAnimation { duration: 540 }
        NumberAnimation { target: scene; property: "unlockFade"; to: 0; duration: 1050; easing.type: Easing.InOutCubic }
    }
    onUnlockingChanged: if (unlocking) {
        password.clear();
        openPanel = "";
    }

    FrameAnimation { running: scene.visible; onTriggered: scene.seconds += frameTime }
    SystemClock { id: clock; precision: SystemClock.Minutes }

    StatsSubscription {
        active: !scene.unlocking && (scene.openPanel === "system" || scene.dashboard)
        fast: true
        keys: ["cpu", "mem", "gpu", "temp", "net"]
    }

    component PlanetButton: Button {
        id: button
        property bool selected: false
        property real iconOpacity: 1
        property real morph: 0
        hoverEnabled: true
        background: Rectangle {
            radius: width / 2 - button.morph * (width / 2 - 26 * scene.unit)
            color: button.selected || button.hovered
                ? Qt.alpha(Colors.primaryContainer, 0.60) : Colors.glass
            border.color: Qt.alpha(Colors.primary, button.selected ? 0.95 : 0.52)
            Behavior on color { ColorAnimation { duration: 220 } }
        }
        contentItem: LockText {
            text: button.text
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: Colors.textOnSurface
            font.family: "Iosevka Nerd Font"
            font.pixelSize: 34 * scene.unit
            opacity: button.iconOpacity
        }
    }

    component GlassButton: Button {
        id: button
        property string glyphFont: Theme.font.family
        property real glyphSize: Math.max(11, 13 * scene.unit)
        property bool emphasized: false
        hoverEnabled: true
        background: Rectangle {
            radius: height / 2
            color: button.hovered || button.emphasized ? Qt.alpha(Colors.primaryContainer, 0.78) : Colors.glass
            border.color: Qt.alpha(Colors.primary, button.enabled ? 0.55 : 0.2)
        }
        contentItem: LockText {
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            text: button.text
            color: Qt.alpha(Colors.textOnSurface, button.enabled ? 1 : 0.45)
            font.family: button.glyphFont
            font.pixelSize: button.glyphSize
        }
    }

    component MediaButton: GlassButton {
        implicitWidth: 36 * scene.unit
        implicitHeight: implicitWidth
        glyphFont: "Iosevka Nerd Font"
        glyphSize: Math.max(14, 20 * scene.unit)
    }

    Rectangle { anchors.fill: parent; color: Colors.backdrop }

    Image {
        anchors.fill: parent
        source: "file://" + scene.cache + "/rofi-wallpaper"
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        visible: status === Image.Ready
        layer.enabled: visible
        layer.effect: MultiEffect {
            blurEnabled: true
            blur: 0.72
            blurMax: 26
            autoPaddingEnabled: false
        }
    }

    Rectangle { anchors.fill: parent; color: Qt.alpha(Colors.backdrop, 0.32) }

    Item {
        id: lockPlanet
        property real shiftX: scene.openPanel === "" || scene.dashboard ? 0 : -290 * scene.unit
        property real shiftY: scene.dashboard ? scene.height * 0.59 - scene.centerY
            : scene.openPanel === "" ? 0 : 96 * scene.unit
        x: scene.centerX - width / 2 + shiftX
        y: scene.centerY - height / 2 + shiftY
        width: (scene.dashboard ? 350 : 270) * scene.unit
        height: width
        z: 12
        scale: scene.openPanel === "" || scene.dashboard ? 1 : 0.66
        opacity: (scene.openPanel === "" || scene.dashboard ? 1 : 0.72) * scene.unlockFade

        Behavior on shiftX { NumberAnimation { duration: 620; easing.type: Easing.InOutCubic } }
        Behavior on shiftY { NumberAnimation { duration: 620; easing.type: Easing.InOutCubic } }
        Behavior on scale { NumberAnimation { duration: 620; easing.type: Easing.InOutCubic } }

        BlackHole {
            anchors.fill: parent
            iconOpacity: 0
            showParticles: scene.unlocking
            opacity: scene.dashboard ? 0 : 1
            boost: scene.unlocking ? 1.35 : 0.45
            Behavior on opacity { NumberAnimation { duration: 380 } }
            Behavior on boost { NumberAnimation { duration: 500 } }
            levels: Spectrum.levels
            pulse: Math.min(1, (levels[0] ?? 0) + (levels[1] ?? 0))
        }

        TapHandler {
            onTapped: {
                scene.togglePanel("dashboard");
            }
        }

        Column {
            anchors.centerIn: parent
            width: Math.min(scene.width - 24, 350 * scene.unit)
            spacing: 11 * scene.unit

            // Draw the lock with Qt items so it does not depend on an icon font.
            Item {
                visible: !scene.dashboard
                anchors.horizontalCenter: parent.horizontalCenter
                width: 45 * scene.unit
                height: 46 * scene.unit
                Rectangle {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: parent.width * 0.58
                    height: parent.height * 0.61
                    radius: width / 2
                    color: "transparent"
                    border.width: Math.max(2, 3 * scene.unit)
                    border.color: Colors.primary
                }
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: parent.height * 0.56
                    radius: 5 * scene.unit
                    color: Colors.primary
                    Rectangle {
                        anchors.centerIn: parent
                        width: 4 * scene.unit
                        height: 9 * scene.unit
                        radius: width / 2
                        color: Colors.backdrop
                    }
                }
            }

            Rectangle {
                visible: scene.dashboard && !scene.unlocking
                width: parent.width
                height: 40 * scene.unit
                radius: height / 2
                color: Colors.glass
                border.color: scene.message ? Colors.danger : Qt.alpha(Colors.primary, 0.55)

                TextInput {
                    id: password
                    anchors.fill: parent
                    anchors.leftMargin: 13 * scene.unit
                    anchors.rightMargin: 13 * scene.unit
                    verticalAlignment: TextInput.AlignVCenter
                    horizontalAlignment: TextInput.AlignHCenter
                    color: Colors.textOnSurface
                    font.pixelSize: Math.max(11, 16 * scene.unit)
                    echoMode: TextInput.Password
                    inputMethodHints: Qt.ImhHiddenText | Qt.ImhSensitiveData | Qt.ImhNoPredictiveText
                    readOnly: scene.checking || scene.unlocking
                    Keys.onEscapePressed: {
                        clear();
                        scene.togglePanel("dashboard");
                    }
                    onAccepted: {
                        if (length > 0 && !scene.checking) {
                            scene.submitted(text);
                            clear();
                        }
                    }

                    LockText {
                        anchors.centerIn: parent
                        visible: password.length === 0
                        text: scene.checking ? "Checking…" : "Password"
                        color: Colors.primary
                        font.pixelSize: Math.max(11, 15 * scene.unit)
                    }
                }
            }

            LockText {
                visible: scene.dashboard && !scene.unlocking
                width: parent.width
                text: scene.message || "Enter to unlock"
                horizontalAlignment: Text.AlignHCenter
                color: scene.message ? Colors.danger : Colors.primary
                font.pixelSize: Math.max(10, 13 * scene.unit)
                elide: Text.ElideRight
            }
        }
    }

    Repeater {
        model: [
            { name: "clock", size: 180 },
            { name: "media", size: 110, icon: "󰎈", label: "Media" },
            { name: "system", size: 110, icon: "󰓃", label: "System info" },
            { name: "battery", size: 88 }
        ]

        OrbitSlot {
            id: orbit
            required property int index
            required property var modelData
            centerX: scene.centerX
            centerY: scene.centerY
            radiusX: scene.width * 0.32
            radiusY: scene.height * 0.32
            phase: scene.phase
            seconds: scene.seconds
            slotIndex: index
            total: 4
            idleWidth: modelData.size * scene.unit
            idleHeight: idleWidth
            readonly property bool calendar: modelData.name === "clock" && scene.openPanel === "calendar"
            readonly property bool selected: calendar || scene.openPanel === modelData.name
            readonly property bool expanded: selected || scene.dashboard
            readonly property bool showDetails: selected || (scene.dashboard
                && (modelData.name === "media" || modelData.name === "system"))

            layoutWidth: (calendar ? 355 : modelData.name === "clock" ? (scene.dashboard ? 282 : 246)
                : modelData.name === "media" ? (scene.dashboard ? Math.min(330, scene.width * 0.215 / scene.unit) : 330)
                : modelData.name === "system" ? 500 : 88) * scene.unit
            layoutHeight: (calendar ? 300 : modelData.name === "clock" ? (scene.dashboard ? 282 : 246)
                : modelData.name === "media" ? 355
                : modelData.name === "system" ? (scene.dashboard ? 182 : 240) : 88) * scene.unit
            layoutX: scene.dashboard && modelData.name === "media" ? scene.width * 0.19
                : scene.dashboard && modelData.name === "battery" ? scene.width * 0.72 : scene.centerX
            layoutY: !scene.dashboard ? scene.centerY
                : modelData.name === "system" ? scene.height * 0.80
                : modelData.name === "media" ? scene.height * 0.40
                : modelData.name === "battery" ? scene.height * 0.18 : scene.dashboardCenterY
            settle: expanded && !scene.unlocking ? 1 : 0
            reveal: scene.unlocking ? 0 : 1
            enabled: !scene.unlocking
            z: selected || settle > 0.4 ? 20 : 10 + depth
            Behavior on settle { NumberAnimation { duration: 620; easing.type: Easing.InOutCubic } }
            Behavior on reveal { NumberAnimation { duration: 440; easing.type: Easing.InCubic } }

            Loader {
                anchors.fill: parent
                sourceComponent: orbit.modelData.name === "clock" ? clockFace
                    : orbit.modelData.name === "battery" ? batteryFace : planetFace
            }

            Component {
                id: clockFace
                Item {
                    TapHandler { onTapped: scene.togglePanel("calendar") }

                    Canvas {
                        id: clockShape
                        anchors.fill: parent
                        readonly property color fill: Colors.glass
                        readonly property color outline: Qt.alpha(Colors.primary, 0.48)
                        onFillChanged: requestPaint()
                        onOutlineChanged: requestPaint()

                        onPaint: {
                            const ctx = getContext("2d");
                            ctx.reset();
                            ctx.beginPath();
                            const base = Math.min(width, height) * 0.45;

                            for (let i = 0; i <= 144; ++i) {
                                const angle = i / 144 * Math.PI * 2;
                                const radius = base * (1 + 0.06 * Math.cos(angle * 12));
                                const x = width / 2 + Math.cos(angle) * radius;
                                const y = height / 2 + Math.sin(angle) * radius;
                                if (i === 0) ctx.moveTo(x, y);
                                else ctx.lineTo(x, y);
                            }

                            ctx.closePath();
                            ctx.fillStyle = fill;
                            ctx.fill();
                            ctx.lineWidth = 1.3;
                            ctx.strokeStyle = outline;
                            ctx.stroke();
                        }

                        RotationAnimation on rotation {
                            from: 0
                            to: 360
                            duration: 55000
                            loops: Animation.Infinite
                            running: scene.visible
                        }
                    }
                    Column {
                        anchors.centerIn: parent
                        opacity: orbit.calendar ? 0 : 1
                        Behavior on opacity { NumberAnimation { duration: 220 } }
                        LockText {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: Qt.formatTime(clock.date, "hh:mm")
                            color: Colors.textOnSurface
                            font.pixelSize: (scene.dashboard ? 57 : 31) * scene.unit
                        }
                        LockText {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: Qt.formatDate(clock.date, "ddd, d MMM")
                            color: Colors.primary
                            font.pixelSize: 12 * scene.unit
                        }
                    }
                }
            }
            Loader {
                anchors.fill: parent
                active: orbit.calendar && orbit.settle > 0.35
                sourceComponent: calendarFace
            }

            Component {
                id: calendarFace
                CalendarPanel {
                    onCloseRequested: scene.togglePanel("calendar")
                }
            }

            Component {
                id: batteryFace
                Rectangle {
                    radius: width / 2
                    color: Colors.glass
                    border.color: Qt.alpha(Colors.primary, 0.8)
                    border.width: 2
                    LockText {
                        anchors.centerIn: parent
                        text: scene.battery ? Math.round(scene.battery.percentage * 100) + "%" : "—"
                        color: Colors.textOnSurface
                        font.pixelSize: 17 * scene.unit
                    }
                }
            }
            Component {
                id: planetFace
                Item {
                    PlanetButton {
                        anchors.fill: parent
                        text: orbit.modelData.icon ?? ""
                        Accessible.name: orbit.modelData.label ?? ""
                        selected: orbit.showDetails
                        opacity: scene.dashboard && orbit.modelData.name === "system" ? Math.max(0, 1 - orbit.settle) : 1
                        morph: orbit.settle
                        iconOpacity: Math.max(0, 1 - orbit.settle * 2.5)
                        onClicked: scene.togglePanel(orbit.modelData.name)
                    }

                    Loader {
                        anchors.fill: parent
                        active: orbit.showDetails && orbit.settle > 0.52
                        opacity: Math.min(1, (orbit.settle - 0.52) / 0.34)
                        enabled: orbit.showDetails
                        sourceComponent: PlanetDetails {
                            kind: orbit.modelData.name
                        }
                    }
                }
            }
        }
    }

    Column {
        x: scene.width * 0.68
        width: Math.min(scene.width * 0.28, 305 * scene.unit)
        y: scene.dashboardCenterY - height / 2
        spacing: 8 * scene.unit
        opacity: scene.dashboard && !scene.unlocking ? 1 : 0
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: 280 } }

        Repeater {
            model: scene.notificationGroups
            Rectangle {
                id: badge
                required property var modelData
                width: parent.width
                height: 42 * scene.unit
                radius: height / 2
                color: Colors.glass
                border.color: Qt.alpha(Colors.primary, 0.35)

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 6 * scene.unit

                    Rectangle {
                        Layout.preferredWidth: 29 * scene.unit
                        Layout.preferredHeight: Layout.preferredWidth
                        radius: width / 2
                        color: Qt.alpha(Colors.primary, 0.3)
                        LockText {
                            anchors.centerIn: parent
                            text: badge.modelData.name.slice(0, 1).toUpperCase()
                            color: Colors.textOnSurface
                        }
                    }
                    LockText {
                        Layout.fillWidth: true
                        text: badge.modelData.name + "  ·  " + badge.modelData.count
                        color: Colors.textOnSurface
                        elide: Text.ElideRight
                    }
                }
            }
        }
    }

    component PlanetDetails: Item {
        id: detail
        required property string kind

        ColumnLayout {
            id: detailContent
            width: parent.width * (detail.kind === "system" && scene.dashboard ? 1 : 0.88)
            anchors.centerIn: parent
            spacing: 8 * scene.unit

            RowLayout {
                Layout.fillWidth: true
                visible: !(scene.dashboard && detail.kind === "system")
                LockText {
                    Layout.fillWidth: true
                    text: detail.kind === "system" ? "System info" : "Media"
                    color: Colors.primary
                    font.bold: true
                    font.pixelSize: Math.max(13, 17 * scene.unit)
                }
                GlassButton {
                    text: "Close"
                    visible: !scene.dashboard
                    onClicked: scene.togglePanel(scene.openPanel)
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                visible: detail.kind === "media"

                Item {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.preferredWidth: 112 * scene.unit
                    Layout.preferredHeight: Layout.preferredWidth
                    visible: cover.status === Image.Ready

                    Image {
                        id: cover
                        anchors.fill: parent
                        source: scene.player?.trackArtUrl ?? ""
                        sourceSize: Qt.size(width, height)
                        asynchronous: true
                        fillMode: Image.PreserveAspectCrop
                        clip: true
                        layer.enabled: true
                        layer.effect: MultiEffect {
                            maskEnabled: true
                            maskSource: coverMask
                            autoPaddingEnabled: false
                        }
                    }

                    Rectangle {
                        id: coverMask
                        anchors.fill: parent
                        radius: width / 14
                        visible: false
                        layer.enabled: true
                    }
                }
                LockText {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    text: scene.player?.trackTitle || "No media playing"
                    color: Colors.textOnSurface
                    elide: Text.ElideRight
                }
                LockText {
                    Layout.fillWidth: true
                    visible: text.length > 0
                    text: scene.player?.trackArtist ?? ""
                    color: Colors.primary
                    elide: Text.ElideRight
                }
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 8 * scene.unit
                    MediaButton {
                        text: "󰒮"
                        Accessible.name: "Previous track"
                        enabled: scene.player?.canGoPrevious ?? false
                        onClicked: scene.player.previous()
                    }
                    MediaButton {
                        text: scene.player?.isPlaying ? "󰏤" : "󰐊"
                        Accessible.name: scene.player?.isPlaying ? "Pause" : "Play"
                        emphasized: true
                        enabled: (scene.player?.isPlaying ? scene.player?.canPause : scene.player?.canPlay) ?? false
                        onClicked: scene.player.togglePlaying()
                    }
                    MediaButton {
                        text: "󰒭"
                        Accessible.name: "Next track"
                        enabled: scene.player?.canGoNext ?? false
                        onClicked: scene.player.next()
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 47 * scene.unit
                    radius: 10 * scene.unit
                    color: Qt.alpha(Colors.backdrop, 0.23)

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 6 * scene.unit
                        spacing: 4 * scene.unit

                        Repeater {
                            model: 10
                            Item {
                                id: band
                                required property int index
                                readonly property real level: Math.min(1, Math.max(0, Spectrum.levels[index] ?? 0))
                                Layout.fillWidth: true
                                Layout.fillHeight: true

                                Rectangle {
                                    anchors.bottom: parent.bottom
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    width: Math.min(parent.width, 8 * scene.unit)
                                    height: parent.height
                                    radius: width / 2
                                    color: Qt.alpha(Colors.primary, 0.12)
                                }
                                Rectangle {
                                    anchors.bottom: parent.bottom
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    width: Math.min(parent.width, 8 * scene.unit)
                                    height: Math.max(2, parent.height * band.level)
                                    radius: width / 2
                                    color: Qt.alpha(Colors.primary, 0.85)
                                    Behavior on height { NumberAnimation { duration: 74; easing.type: Easing.OutCubic } }
                                }
                            }
                        }
                    }
                }
            }

            Loader {
                Layout.fillWidth: true
                active: detail.kind === "system"
                visible: active
                sourceComponent: SystemGrid {
                    unit: scene.unit
                    monitoring: !scene.unlocking && (scene.dashboard || scene.openPanel === "system")
                }
            }
        }
    }
}
