#!/usr/bin/env bash
set -euo pipefail

config="${XDG_CONFIG_HOME:-$HOME/.config}"
picker="$config/quickshell/hyprquickpaper"
wallpaper_dir=$(jq -r '.wallpaper_path // "$HOME/Pictures/Wallpapers"' "$picker/config.json")
wallpaper_dir=${wallpaper_dir//\$HOME/$HOME}
if [[ ! -d "$wallpaper_dir" ]]; then
    notify-send "Wallpaper picker" "Wallpaper folder not found: $wallpaper_dir"
    exit 1
fi

mapfile -d '' -t wallpapers < <(
    find -L "$wallpaper_dir" -maxdepth 1 -type f \
        \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \
           -o -iname '*.gif' -o -iname '*.mp4' -o -iname '*.mkv' -o -iname '*.webm' \
           -o -iname '*.mov' \) -printf '%T@ %p\0' |
        sort -z -nr | cut -z -d ' ' -f 2-
)
if (( ${#wallpapers[@]} == 0 )); then
    notify-send "Wallpaper picker" "No wallpapers found in $wallpaper_dir"
    exit 1
fi

rows() {
    local path icon name
    for path in "${wallpapers[@]}"; do
        name=${path##*/}
        icon=$path
        case "${path,,}" in
            *.mp4|*.mkv|*.webm|*.mov) icon=video-x-generic ;;
        esac
        printf '%s\0icon\x1f%s\n' "${name//$'\n'/ }" "${icon//$'\n'/ }"
    done
}

picker_theme='mode-switcher { enabled: false; } entry { placeholder: "Search wallpapers"; } element-icon { size: 52px; } listview { lines: 6; }'
picker_args=()
if [[ -r "$HOME/.cache/43pr/rofi-glass-picker.rasi" ]]; then
    picker_args=(-theme-str '@import "~/.cache/43pr/rofi-glass-picker.rasi"')
fi
if ! index=$(rows | rofi -dmenu -no-custom -no-sort -format i -p '' \
    -theme-str "$picker_theme" "${picker_args[@]}"); then
    exit 0
fi
[[ "$index" =~ ^[0-9]+$ ]] && (( index < ${#wallpapers[@]} )) || exit 0

transition=outer
duration=1
if [[ -r "$picker/settings.json" ]]; then
    transition=$(jq -r '.transition // "outer"' "$picker/settings.json") || transition=outer
    duration=$(jq -r '.transitionDuration // 1' "$picker/settings.json") || duration=1
fi
exec bash "$picker/commands.sh" "${wallpapers[index]}" "$transition" "$duration"
