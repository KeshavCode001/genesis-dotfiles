#!/usr/bin/env bash
set -euo pipefail

target=/var/lib/43pr-sddm
wallpaper=${1:-"$HOME/.cache/43pr/rofi-wallpaper"}
[[ -d "$target" && -w "$target" && -r "$wallpaper" ]] || exit 0

temp=$(mktemp "$target/.wallpaper.XXXXXX")
trap 'rm -f -- "$temp"' EXIT
magick "${wallpaper}[0]" -auto-orient -resize '2560x2560>' \
    -background black -alpha remove -alpha off -strip -quality 90 "jpeg:$temp"
chmod 644 "$temp"
mv -fT -- "$temp" "$target/wallpaper.jpg"
