//@ pragma UseQApplication
import Quickshell
import "colorpicker"

ShellRoot {
    VolumeOsd {}
    ScreenshotOsd {}
    SettingsWindow {}
    RecorderOSD {}
    PowerMenu {}
    WaybarHost {
        id: desktopPanel
        notificationSource: sidePanel.notificationSource
    }
    SidePanel {
        id: sidePanel
        pocketNotifications: desktopPanel.pocketVisible
        onPocketNotification: notification => desktopPanel.notifyPocket(notification)
    }
    Todo {}
    ColorPicker {}
}
