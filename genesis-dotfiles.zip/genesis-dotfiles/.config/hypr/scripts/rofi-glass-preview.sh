#!/usr/bin/env bash
set -euo pipefail

cache="$HOME/.cache/43pr"
wallpaper="$cache/rofi-wallpaper"
[[ -r "$wallpaper" ]] || exit 0

# The preview is scaled to the left pane by Rofi. Keep the blur inside
# the search field and tab fills, with an inset for their rounded edges.
tmp=$(mktemp -d "$cache/rofi-glass.XXXXXX")
trap 'rm -r -- "$tmp"' EXIT
magick "${wallpaper}[0]" -background black -alpha remove -alpha off \
    -resize '1000x1000^' -gravity northwest -extent 1000x1000 "$tmp/sharp.png"
magick "$tmp/sharp.png" -blur 0x11 "$tmp/blur.png"

make_preview() {
    local name=$1 shapes=$2
    magick "$tmp/blur.png" \
        \( -size 1000x1000 xc:black -fill white -draw "$shapes" -blur 0x4 \) \
        -alpha off -compose CopyOpacity -composite "$tmp/masked.png"
    magick "$tmp/sharp.png" "$tmp/masked.png" -compose Over -composite "$tmp/$name.png"
    mv -f -- "$tmp/$name.png" "$cache/$name.png"
}

search='roundrectangle 49,48 951,121 14,14'
tabs='roundrectangle 49,875 308,950 14,14 roundrectangle 371,875 629,950 14,14 roundrectangle 692,875 951,950 14,14'
make_preview rofi-glass-launcher "$search $tabs"
make_preview rofi-glass-picker "$search"

printf '%s\n' 'imagebox { background-image: url("~/.cache/43pr/rofi-glass-launcher.png", both); }' > "$tmp/rofi-glass.rasi"
mv -f -- "$tmp/rofi-glass.rasi" "$cache/rofi-glass.rasi"
printf '%s\n' 'imagebox { background-image: url("~/.cache/43pr/rofi-glass-picker.png", both); }' > "$tmp/rofi-glass-picker.rasi"
mv -f -- "$tmp/rofi-glass-picker.rasi" "$cache/rofi-glass-picker.rasi"
