pragma Singleton
import QtQuick

QtObject {
    readonly property QtObject lock: QtObject {
        readonly property color space: "#05050f"
        readonly property color star: "#e9e4ff"
        readonly property int twinklers: 18
        readonly property int ringDots: 90
        readonly property real ringTilt: 0.32
        readonly property int holeSize: 160
        readonly property real pulseGain: 0.45
        readonly property real centerHeight: 0.42
        readonly property real depthScale: 0.14
        readonly property real depthOpacity: 0.35
        readonly property int bob: 6
        readonly property int bobPeriod: 7
        readonly property real spiralTurn: 2.8
        readonly property real wingStartScale: 0.3
    }
    readonly property QtObject galaxy: QtObject {
        readonly property int stars: 160
        readonly property real starFaint: 0.25
        readonly property real starBright: 0.6
    }
    readonly property QtObject font: QtObject {
        readonly property string family: "Monocraft"
        readonly property string icons: "sans-serif"
        readonly property int small: 12
    }
    readonly property QtObject anim: QtObject {
        readonly property int slow: 400
        readonly property var standard: [0.2, 0, 0, 1, 1, 1]
    }
}
