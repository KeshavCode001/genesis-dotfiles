#!/usr/bin/env python3
"""Generate the Waybar config from the graphical editor's settings."""
import json
import os
import runpy
import sys
import subprocess
import tempfile
from pathlib import Path

CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
STATE = CONFIG_HOME / "quickshell" / "state" / "waybar.json"
SOURCE = Path(__file__).resolve().parent
RUNTIME = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "43pr" / "waybar"
DEFAULTS = json.loads((SOURCE / "layout.json").read_text())
MODULES = json.loads((SOURCE / "modules.json").read_text())
SECTIONS = ("left", "center", "right")
THEME_ROOT = CONFIG_HOME / "43pr"


def palette_css():
    theme = runpy.run_path(str(THEME_ROOT / "bin" / "theme.py"))
    template = THEME_ROOT / "templates" / "waybar-colors.css"
    active = theme["PALETTE"]
    if active.is_file():
        colors = theme["merged"](json.loads(active.read_text()))
    else:
        colors = theme["preset_palette"]("default")
    return theme["render"](template.read_text(), colors, "waybar")


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, mode="w", delete=False) as output:
        output.write(content)
    os.replace(output.name, path)


def normalize(settings):
    result = DEFAULTS | {key: settings[key] for key in DEFAULTS if key in settings}
    if result["position"] not in ("top", "bottom"):
        result["position"] = DEFAULTS["position"]
    for key, low, high in (("scale", 0.8, 2), ("margin", 0, 24),
                           ("spacing", 0, 20), ("opacity", 10, 100), ("fontSize", 8, 22),
                           ("fontWeight", 100, 900), ("radius", 0, 36), ("tint", 0, 50)):
        value = result[key]
        result[key] = max(low, min(high, value)) if type(value) in (int, float) else DEFAULTS[key]
    for key in ("reserveSpace", "clock24", "blur"):
        if not isinstance(result[key], bool):
            result[key] = DEFAULTS[key]
    used = set()
    for section in SECTIONS:
        modules = result[section]
        result[section] = []
        if not isinstance(modules, list):
            modules = DEFAULTS[section]
        for name in modules:
            if isinstance(name, str) and name in MODULES and name not in used and name != "pulseaudio#microphone":
                result[section].append(name)
                used.add(name)
    return result


def build(settings):
    scale = settings["scale"]
    margin = settings["margin"]
    font_px = round(settings["fontSize"] * scale)
    inset = max(2, round(3 * scale))
    height = max(round(38 * scale), round(1.5 * font_px) + 2 * inset + 4)
    options = {
        "layer": "top",
        "position": settings["position"],
        "height": height,
        "exclusive": settings["reserveSpace"],
        "fixed-center": True,
        "margin-top": margin if settings["position"] == "top" else 0,
        "margin-bottom": margin if settings["position"] == "bottom" else 0,
        "margin-left": margin + 4,
        "margin-right": margin + 4,
        "reload_style_on_change": True,
    }
    config = MODULES | options
    config["tray"] = MODULES["tray"] | {"icon-size": round(16 * scale)}
    config["clock"] = MODULES["clock"] | {"format": "{:%H:%M}" if settings["clock24"] else "{:%I:%M %p}"}
    if settings["workspaceLabels"] == "kanji":
        config["hyprland/workspaces"] = MODULES["hyprland/workspaces"] | {
            "format-icons": dict(zip(map(str, range(1, 11)), "一二三四五六七八九十")),
        }
    for section in SECTIONS:
        group = f"group/section-pill#{section}"
        config[f"modules-{section}"] = [group] if settings[section] else []
        config[group] = {"orientation": "inherit", "modules": settings[section]}
    metrics = f"""
@define-color bar_panel alpha(mix(@bar_surface, @bar_accent, {settings["tint"] / 100:.2f}), {settings["opacity"] / 100:.2f});
* {{ font-size: {font_px}px; font-weight: {round(settings["fontWeight"] / 100) * 100}; }}
#section-pill {{
    padding: {inset}px {round(8 * scale)}px;
    border-radius: {round(settings["radius"] * scale)}px;
}}
#section-pill > * + * {{ margin-left: {round(settings["spacing"] * scale)}px; }}
#section-pill.empty {{ padding: 0; border-width: 0; }}
#clock, #battery, #custom-power, #custom-notifications, #pulseaudio, #tray,
#custom-settings, #custom-launcher, #custom-wallpaper, #backlight, #cpu, #memory, #network, #mpris {{
    padding: 0 {round(7 * scale)}px;
}}
#workspaces button {{ padding: 0 {round(8 * scale)}px; }}
"""
    shared = RUNTIME / "colors.css"
    if not shared.exists() or "@define-color bar_surface " not in shared.read_text():
        write(shared, palette_css())
    write(RUNTIME / "config.json", json.dumps(config, indent=2) + "\n")
    write(RUNTIME / "metrics.css", metrics)
    write(RUNTIME / "style.css", (SOURCE / "style.css").read_text())


def sync_blur(enabled):
    path = RUNTIME / "blur.lua"
    value = "true" if enabled else "false"
    rule = (
        'hl.layer_rule({ name = "43pr-waybar-blur", match = { namespace = "^waybar$" }, '
        f'blur = {value}, blur_popups = true, ignore_alpha = 0.05 }})\n'
    )
    if path.exists() and path.read_text() == rule:
        return
    write(path, rule)
    if os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
        subprocess.run(["hyprctl", "reload", "config-only"], check=True, stdout=subprocess.DEVNULL)


def enable_click_filter():
    source = SOURCE / "ignore-secondary-click.c"
    library = RUNTIME / "ignore-secondary-click.so"
    if not library.exists() or library.stat().st_mtime_ns < source.stat().st_mtime_ns:
        flags = subprocess.check_output(["pkg-config", "--cflags", "--libs", "gtk+-3.0"], text=True).split()
        with tempfile.TemporaryDirectory(dir=RUNTIME) as build_dir:
            output = Path(build_dir) / library.name
            subprocess.run(["cc", "-shared", "-fPIC", "-o", str(output), str(source), *flags], check=True)
            os.replace(output, library)

    modules = os.environ.get("GTK_MODULES")
    os.environ["GTK_MODULES"] = f"{modules}:{library}" if modules else str(library)


def main():
    mode = sys.argv[1]
    try:
        settings = json.loads(sys.argv[2]) if mode == "apply" else json.loads(STATE.read_text())
    except (OSError, json.JSONDecodeError):
        if mode == "apply":
            raise
        settings = DEFAULTS
    settings = normalize(settings)
    build(settings)
    sync_blur(settings["blur"])
    write(STATE, json.dumps(settings, indent=2) + "\n")
    if mode == "run":
        try:
            enable_click_filter()
        except (OSError, subprocess.SubprocessError) as error:
            print(f"Waybar tray right-click filter unavailable: {error}", file=sys.stderr)
        os.execvp("waybar", ["waybar", "-c", str(RUNTIME / "config.json"), "-s", str(RUNTIME / "style.css")])


if __name__ == "__main__":
    main()
