import QtQuick
import QtQuick.Layouts
import Quickshell.Io

GridLayout {
    id: grid
    required property real unit
    required property bool monitoring
    property real diskUsed: -1
    property real diskTotal: -1
    property real diskPercent: 0
    columns: 3
    uniformCellWidths: true
    columnSpacing: 8 * unit
    rowSpacing: 8 * unit

    function size(bytes) {
        return bytes < 0 ? "—" : (bytes / 1073741824).toFixed(1) + "G";
    }

    function rate(bytes) {
        if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB/s";
        if (bytes >= 1024) return (bytes / 1024).toFixed(1) + " KB/s";
        return Math.round(bytes) + " B/s";
    }

    onMonitoringChanged: if (monitoring) disk.running = true
    Component.onCompleted: if (monitoring) disk.running = true
    Timer {
        interval: 10000
        repeat: true
        running: grid.monitoring
        onTriggered: disk.running = true
    }

    Process {
        id: disk
        command: ["df", "-B1", "--output=size,used,pcent", "/"]
        stdout: SplitParser {
            onRead: line => {
                const match = line.trim().match(/^(\d+)\s+(\d+)\s+(\d+)%$/);
                if (!match) return;
                grid.diskTotal = Number(match[1]);
                grid.diskUsed = Number(match[2]);
                grid.diskPercent = Number(match[3]);
            }
        }
    }

    readonly property var readings: ({
            CPU: { icon: "󰻠", value: Math.round(SystemStats.cpuUsage) + "%", fill: SystemStats.cpuUsage, tint: Colors.primary },
            RAM: { icon: "󰍛", value: grid.size(SystemStats.memUsedKb * 1024), fill: SystemStats.memPercent, tint: Colors.tertiary },
            GPU: { icon: "󰢮", value: SystemStats.gpuHasUsage ? SystemStats.gpuUsage + "%" : "—", fill: SystemStats.gpuHasUsage ? SystemStats.gpuUsage : 0, tint: Colors.secondary },
            TEMP: { icon: "󰔏", value: SystemStats.cpuTemp >= 0 ? SystemStats.cpuTemp + "°" : "—", fill: Math.max(0, SystemStats.cpuTemp), tint: Colors.primary },
            DISK: { icon: "󰋊", value: grid.diskTotal >= 0 ? grid.diskPercent + "%" : "—", note: grid.size(grid.diskUsed), fill: grid.diskPercent, tint: Colors.tertiary },
            NET: { icon: "󰓅", value: "↓ " + grid.rate(SystemStats.netDown), note: "↑ " + grid.rate(SystemStats.netUp), fill: 5, tint: Colors.secondary }
            })

    Repeater {
        model: ["CPU", "RAM", "GPU", "TEMP", "DISK", "NET"]

        Rectangle {
            id: card
            required property string modelData
            readonly property var reading: grid.readings[modelData]
            Layout.fillWidth: true
            Layout.preferredHeight: 83 * grid.unit
            radius: 15 * grid.unit
            color: Qt.alpha(Colors.primaryContainer, 0.64)
            border.color: Qt.alpha(reading.tint, 0.3)

            Canvas {
                anchors.fill: parent
                readonly property real level: Math.max(0, Math.min(1, card.reading.fill / 100))
                readonly property color tint: Qt.alpha(card.reading.tint, 0.4)
                onLevelChanged: requestPaint()
                onTintChanged: requestPaint()
                onWidthChanged: requestPaint()
                onHeightChanged: requestPaint()
                onPaint: {
                    const ctx = getContext("2d");
                    ctx.reset();
                    const r = Math.min(card.radius, width / 2, height / 2);
                    ctx.beginPath();
                    ctx.moveTo(r, 0);
                    ctx.arcTo(width, 0, width, height, r);
                    ctx.arcTo(width, height, 0, height, r);
                    ctx.arcTo(0, height, 0, 0, r);
                    ctx.arcTo(0, 0, width, 0, r);
                    ctx.closePath();
                    ctx.clip();
                    const y = height * (1 - level);
                    const wave = Math.min(4 * grid.unit, height * level / 3);
                    ctx.beginPath();
                    ctx.moveTo(0, y);
                    ctx.bezierCurveTo(width * 0.28, y - wave, width * 0.48, y + wave, width * 0.62, y);
                    ctx.quadraticCurveTo(width * 0.82, y - wave, width, y);
                    ctx.lineTo(width, height);
                    ctx.lineTo(0, height);
                    ctx.closePath();
                    ctx.fillStyle = tint;
                    ctx.fill();
                }
            }

            Text {
                anchors.left: parent.left; anchors.top: parent.top; anchors.margins: 8 * grid.unit
                text: card.reading.icon
                font.family: "Iosevka Nerd Font"
                font.pixelSize: Math.max(11, 15 * grid.unit)
                color: card.reading.tint
            }
            Text {
                anchors.right: parent.right; anchors.top: parent.top; anchors.margins: 8 * grid.unit
                text: card.modelData
                font.family: Theme.font.family
                font.pixelSize: Math.max(9, 11 * grid.unit)
                color: Colors.textOnSurface
            }
            Column {
                anchors.right: parent.right; anchors.left: parent.left; anchors.bottom: parent.bottom
                anchors.margins: 8 * grid.unit
                Text {
                    width: parent.width
                    text: card.reading.value
                    horizontalAlignment: Text.AlignRight
                    elide: Text.ElideRight
                    font.family: Theme.font.family
                    font.pixelSize: Math.max(10, (card.modelData === "NET" ? 11 : 20) * grid.unit)
                    color: Colors.textOnSurface
                }
                Text {
                    width: parent.width
                    visible: text.length > 0
                    text: card.reading.note ?? ""
                    horizontalAlignment: Text.AlignRight
                    elide: Text.ElideRight
                    font.family: Theme.font.family
                    font.pixelSize: Math.max(9, 10 * grid.unit)
                    color: Colors.textOnSurface
                }
            }
        }
    }
}
