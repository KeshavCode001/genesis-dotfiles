// SettingsAbout.qml — system information. A single shell pass, not a poll:
// none of this changes while you look at the window (except the uptime, which
// refreshes when you come back into the section).
//
// Every item also carries its value as `hint`, so if the text does not fit in
// the row (the processor name, for example) it appears in full in the footer
// strip when you hover over it.
import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Flickable {
    id: root

    property string note: I18n.tr("Una sola pasada al entrar en la sección; nada de sondeos en bucle.")
    readonly property int matchCount: cSw.visibleRows + cHw.visibleRows + cRice.visibleRows

    contentHeight: col.implicitHeight + 34
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded; width: 5 }

    property var info: ({})

    onVisibleChanged: {
        if (!visible) return;
        contentY = 0;
        probe.running = true;
    }

    Process {
        id: probe
        command: ["bash", "-lc", `
            printf 'distro\\t%s\\n' "$(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME")"
            printf 'kernel\\t%s\\n' "$(uname -r)"
            printf 'wm\\t%s\\n'     "Hyprland $(hyprctl version 2>/dev/null | head -1 | grep -oP '\\d+\\.\\d+\\.\\d+' | head -1)"
            printf 'shell\\t%s\\n'  "Quickshell $(quickshell --version 2>/dev/null | grep -oP '\\d+\\.\\d+\\.\\d+' | head -1)"
            printf 'cpu\\t%s\\n'    "$(awk -F': ' '/model name/{print $2; exit}' /proc/cpuinfo)"
            printf 'ram\\t%s\\n'    "$(free -h --si | awk '/^Mem:/{print $3" ${I18n.tr("de")} "$2}')"
            printf 'disk\\t%s\\n'   "$(df -h --output=used,size,pcent / | tail -1 | awk '{print $1" ${I18n.tr("de")} "$2" ("$3")"}')"
            printf 'up\\t%s\\n'     "$(awk '{s=int($1); d=int(s/86400); h=int(s%86400/3600); m=int(s%3600/60);
                                          if(d>0) printf "%d d %d h %d min", d, h, m;
                                          else if(h>0) printf "%d h %d min", h, m;
                                          else printf "%d min", m}' /proc/uptime)"
            printf 'pkgs\\t%s\\n'   "$(pacman -Qq 2>/dev/null | wc -l) ${I18n.tr("paquetes")}"
            [ -r "$HOME/.config/motion-language.md" ] && printf 'motion\\t1\\n'
        `]
        stdout: SplitParser {
            onRead: function (line) {
                const p = line.split("\t");
                if (p.length < 2) return;
                const o = root.info;
                o[p[0]] = p[1];
                root.info = o;
                root.infoChanged();
            }
        }
    }

    readonly property var hw: [
        { k: "kernel", label: I18n.tr("Kernel") },
        { k: "cpu",    label: I18n.tr("Procesador") },
        { k: "ram",    label: I18n.tr("Memoria") },
        { k: "disk",   label: I18n.tr("Disco raíz") },
        { k: "up",     label: I18n.tr("Encendido desde hace") },
        { k: "pkgs",   label: I18n.tr("Paquetes instalados") }
    ]

    readonly property var sw: [
        { k: "distro", label: I18n.tr("Sistema") },
        { k: "wm",     label: I18n.tr("Compositor") },
        { k: "shell",  label: I18n.tr("Shell") }
    ]

    ColumnLayout {
        id: col
        width: root.width - 48
        x: 24
        y: 16
        spacing: 10

        // ─────────────────── header with the logo ───────────────────
        RowLayout {
            Layout.fillWidth: true
            Layout.bottomMargin: 4
            spacing: 18
            visible: ShellState.settingsQuery.length === 0

            Text {
                text: Icons.arch
                color: Colors.accent
                font.family: Appearance.font
                font.pixelSize: 46
            }
            ColumnLayout {
                spacing: 2
                Text {
                    text: root.info["distro"] || "Arch Linux"
                    color: Colors.label
                    font.family: Appearance.fontUI
                    font.pixelSize: 17
                    font.weight: Font.DemiBold
                }
                Text {
                    text: root.info["wm"] || ""
                    color: Colors.label2
                    font.family: Appearance.fontUI
                    font.pixelSize: Appearance.fsS
                }
            }
        }

        SettingsControls.Card_ {
            id: cSw
            title: I18n.tr("Software")
            Repeater {
                model: root.sw
                onItemAdded: cSw.recount()
                SettingsControls.Row_ {
                    required property var modelData
                    label: modelData.label
                    hint: root.info[modelData.k] || ""
                    SettingsControls.Val_ { text: root.info[modelData.k] || "…" }
                }
            }
        }

        SettingsControls.Card_ {
            id: cHw
            title: I18n.tr("Hardware")
            Repeater {
                model: root.hw
                onItemAdded: cHw.recount()
                SettingsControls.Row_ {
                    required property var modelData
                    label: modelData.label
                    hint: root.info[modelData.k] || ""
                    SettingsControls.Val_ { text: root.info[modelData.k] || "…" }
                }
            }
        }

        SettingsControls.Card_ {
            id: cRice
            title: I18n.tr("Este rice")

            SettingsControls.Row_ {
                label: I18n.tr("Ajustes guardados en")
                hint: I18n.tr("El JSON que escribe la sección Apariencia. Bórralo y todo vuelve a los valores de fábrica.")
                SettingsControls.Val_ { text: "~/.config/quickshell-rice.json" }
            }
            SettingsControls.Row_ {
                label: I18n.tr("Código del shell")
                hint: I18n.tr("Barra, notch, paneles, lanzador, selector de fondos y esta misma ventana.")
                SettingsControls.Val_ { text: "~/.config/quickshell/" }
            }
            SettingsControls.Row_ {
                // ONLY IF THE FILE IS REALLY THERE.
                //
                // The motion spec is a working notebook, not configuration,
                // so it is not versioned. On a freshly cloned install it does
                // not exist, and showing the path anyway would send the user to
                // an empty place from the one screen of the desktop that exists
                // to tell them where things are.
                shown: root.info["motion"] === "1"
                label: I18n.tr("Lenguaje de movimiento")
                hint: I18n.tr("La spec de duraciones, curvas y forma que siguen Hyprland y Quickshell.")
                SettingsControls.Val_ { text: "~/.config/motion-language.md" }
            }
        }

        SettingsControls.Note_ {
            Layout.topMargin: 10
            visible: ShellState.settingsQuery.length > 0 && !cSw.visible && !cHw.visible && !cRice.visible
            text: I18n.tr("Nada de Acerca de coincide con «{0}».", ShellState.settingsQuery)
        }
    }
}
