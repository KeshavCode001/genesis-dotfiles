import QtQuick
import Quickshell
import Quickshell.Services.Pam
import Quickshell.Wayland

ShellRoot {
    id: root
    property string pendingPassword: ""
    property string message: ""
    property bool unlocking: false

    function finishUnlock() {
        if (!unlocking || !session.locked) return;
        unlockTimer.stop();
        session.locked = false;
        quitTimer.start();
    }

    WlSessionLock {
        id: session
        Component.onCompleted: {
            Quickshell.watchFiles = false;
            locked = true;
        }

        WlSessionLockSurface {
            color: Colors.backdrop
            LockScene {
                anchors.fill: parent
                checking: pam.active
                unlocking: root.unlocking
                onUnlockAnimationFinished: root.finishUnlock()
                message: root.message
                onSubmitted: password => {
                    if (!session.secure || pam.active || root.unlocking) return;
                    root.message = "";
                    root.pendingPassword = password;
                    if (!pam.start()) {
                        root.pendingPassword = "";
                        root.message = "Authentication error";
                    }
                }
            }
        }
    }

    Timer {
        id: unlockTimer
        interval: 2500
        onTriggered: root.finishUnlock()
    }
    Timer { id: quitTimer; interval: 150; onTriggered: Qt.quit() }

    PamContext {
        id: pam
        config: "hyprlock"

        onPamMessage: {
            if (!responseRequired) return;
            const password = root.pendingPassword;
            root.pendingPassword = "";
            respond(password);
        }

        onCompleted: result => {
            root.pendingPassword = "";
            if (result === PamResult.Success) {
                root.unlocking = true;
                unlockTimer.start();
            } else {
                root.message = result === PamResult.Error ? "Authentication error" : "Password rejected";
            }
        }

        onError: {
            root.pendingPassword = "";
            root.message = "Authentication error";
        }
    }
}
