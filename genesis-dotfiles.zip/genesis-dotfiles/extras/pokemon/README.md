# Optional desktop Pokémon

The desktop mascot runs independently of Waybar and the Pocket Dots notch. It uses the Pocket Dots team tools and the wl_shimeji Wayland overlay.

1. Install [wl_shimeji](https://github.com/CluelessCatBurger/wl_shimeji) and Python Pillow, for example via `wl_shimeji-git` and `python-pillow` on Arch. Make `shimejictl` and `shimeji-overlayd` available on your PATH. If you installed system-wide, change the copied `wl_shimeji.service` executable path to match your installation. The cursor plugin directory is optional.
2. Copy the executable scripts from [bin/](bin/) to `~/.local/bin`. Ensure it is on your shell PATH.
3. Place English Shimeji-ee `actions.xml` and `behaviors.xml` from the [Shimeji-ee configuration](https://github.com/MisakoChan/shimeji-ee/tree/master/conf) in `~/.local/share/shimejis/plantilla/`.
4. Run `poke-team add 133` to add Eevee and `poke-team pasear on` to enable walking. From Hyprland, run `systemctl --user daemon-reload`, then `systemctl --user import-environment WAYLAND_DISPLAY HYPRLAND_INSTANCE_SIGNATURE` and `systemctl --user start 43pr-pokemon.path 43pr-pokemon.timer`.

The same units start from the Hyprland configuration on login. Use `poke-team pasear off` to disable walking. The local team save and sprite cache are generated per user. GitHub-based progression is disabled in the notch.
