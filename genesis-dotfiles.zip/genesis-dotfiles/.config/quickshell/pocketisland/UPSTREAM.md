Pocket Dots by Diego Malagrida, licensed under GPL-3.0. See LICENSE.

Source: https://github.com/diegoMalagrida/pocket-dots/tree/f1480297f2f7b2f806675ee362fbecc5218d5a9a/home/.config/quickshell

43PR uses the original TopShell and panels with an isolated entrypoint, a 43PR palette adapter and local script paths.
