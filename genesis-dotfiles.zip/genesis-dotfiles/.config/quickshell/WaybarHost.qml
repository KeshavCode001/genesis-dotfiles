import QtQuick
import Quickshell
import Quickshell.Io
import "pocketisland" as Pocket

Scope {
    id: root
    readonly property string configHome: Quickshell.env("XDG_CONFIG_HOME") || Quickshell.env("HOME") + "/.config"
    property bool islandMode: false
    property bool hidden: false
    property bool loaded: false
    readonly property bool pocketVisible: pocketLoader.item !== null
    property var notificationSource

    function notifyPocket(notification) {
        if (pocketVisible) Pocket.ShellState.acceptNotification(notification);
    }

    FileView {
        id: modeFile
        path: root.configHome + "/quickshell/state/panel-mode"
        printErrors: false
        onLoaded: {
            root.islandMode = text().trim() === "island";
            root.loaded = true;
        }
        onLoadFailed: root.loaded = true
    }

    Process {
        id: barProcess
        running: root.loaded && !root.islandMode && !root.hidden && !root.pocketVisible
        command: ["python3", root.configHome + "/waybar/configure.py", "run"]
        stderr: SplitParser { onRead: line => console.warn(line) }
    }

    LazyLoader {
        id: pocketLoader
        active: root.loaded && root.islandMode && !root.hidden && !barProcess.running
        Pocket.PocketIsland { notificationSource: root.notificationSource }
    }

    IpcHandler {
        target: "bar"
        function toggle(): void {
            root.hidden = !root.hidden;
        }
        function swap(): void {
            if (!root.loaded) return;
            root.islandMode = !root.islandMode;
            root.hidden = false;
            modeFile.setText(root.islandMode ? "island\n" : "waybar\n");
        }
        function mode(): string {
            return root.islandMode ? "island" : "waybar";
        }
        function reload(): void {
            if (barProcess.running) barProcess.signal(12);
        }
        function customize(): void {
            Quickshell.execDetached(["qs", "ipc", "call", "settings", "bar"]);
        }
    }
}
