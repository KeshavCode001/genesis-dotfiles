# Nebula session lock port

The black hole, cloud, star, moon, and orbit components are adapted from [Nebula](https://github.com/LilaccFlowerr/Nebula/tree/9749c30402b4e6712d0222c48b645fa357d0217e/quickshell/nebula/widgets/lock), licensed under AGPL-3.0. The 43PR port changes the component imports, theme, and lock scene integration. See LICENSE.
