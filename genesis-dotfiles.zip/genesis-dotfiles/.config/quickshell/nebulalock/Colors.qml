pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

QtObject {
    readonly property color primary: palette.qs_accent || palette.accent || "#b6a5ff"
    readonly property color tertiary: palette.qs_accent2 || palette.highlight || "#f3a6cf"
    readonly property color secondary: Qt.tint(primary, Qt.alpha(tertiary, 0.4))
    readonly property color inversePrimary: primary
    readonly property color primaryContainer: Qt.tint(backdrop, Qt.alpha(primary, 0.24))
    readonly property color backdrop: palette.qs_bg || palette.bg || Theme.lock.space
    readonly property color textOnSurface: palette.qs_text || "#f4efff"
    readonly property color danger: palette.qs_danger || "#ef9caa"
    readonly property color glass: Qt.alpha(primaryContainer, 0.60)
    property var palette: ({})

    readonly property FileView paletteFile: FileView {
        path: (Quickshell.env("XDG_CACHE_HOME") || Quickshell.env("HOME") + "/.cache") + "/43pr/palette.json"
        printErrors: false
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            try { palette = JSON.parse(text()); }
            catch (error) { console.warn("Lock palette:", error); }
        }
    }
}
