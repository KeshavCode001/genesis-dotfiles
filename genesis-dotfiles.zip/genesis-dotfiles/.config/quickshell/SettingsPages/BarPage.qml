import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../"

ScrollView {
    id: page
    contentWidth: availableWidth
    clip: true
    readonly property string configHome: Quickshell.env("XDG_CONFIG_HOME") || Quickshell.env("HOME") + "/.config"
    readonly property var sections: ["left", "center", "right"]
    readonly property var catalog: [
        ["clock", "Clock"], ["tray", "System tray"], ["hyprland/workspaces", "Workspaces"],
        ["custom/notifications", "Notifications"], ["battery", "Battery"],
        ["group/audio", "Audio and microphone"], ["custom/power", "Power menu"],
        ["custom/settings", "Bar settings"], ["custom/launcher", "App launcher"],
        ["custom/wallpaper", "Wallpapers"], ["backlight", "Brightness"], ["cpu", "CPU"],
        ["memory", "Memory"], ["network", "Network"], ["mpris", "Now playing"]
    ]
    property var saved: ({})
    property var draft: ({})
    property string status: ""
    property string errorOutput: ""
    readonly property bool ready: draft.position !== undefined
    readonly property bool dirty: JSON.stringify(saved) !== JSON.stringify(draft)

    function setValue(key, value) {
        draft = Object.assign({}, draft, { [key]: value });
        status = "";
    }

    function sectionIndex(id) {
        const index = sections.findIndex(section => (draft[section] ?? []).includes(id));
        return index < 0 ? 3 : index;
    }

    function putModule(id, location) {
        const next = Object.assign({}, draft);
        for (const section of sections) next[section] = (next[section] ?? []).filter(item => item !== id);
        if (location < sections.length) next[sections[location]].push(id);
        draft = next;
        status = "";
    }

    function moveModule(id, offset) {
        const section = sections[sectionIndex(id)];
        if (!section) return;
        const order = draft[section].slice();
        const index = order.indexOf(id);
        const target = index + offset;
        if (target < 0 || target >= order.length) return;
        order.splice(index, 1);
        order.splice(target, 0, id);
        setValue(section, order);
    }

    function orderLabel(id) {
        const section = sections[sectionIndex(id)];
        return section ? String(draft[section].indexOf(id) + 1) : "";
    }

    FileView {
        id: stateFile
        path: page.configHome + "/quickshell/state/waybar.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            const wasDirty = page.saved.position !== undefined && page.dirty;
            try {
                page.saved = JSON.parse(text());
                if (!wasDirty) page.draft = page.saved;
            } catch (error) {
                page.status = "Could not read saved settings";
            }
        }
    }

    FileView {
        id: defaultsFile
        path: page.configHome + "/waybar/layout.json"
        onLoaded: if (!page.ready) page.draft = JSON.parse(text())
    }

    Process {
        id: applyProcess
        stderr: SplitParser { onRead: line => page.errorOutput = line }
        onExited: function(exitCode) {
            if (exitCode === 0) {
                page.saved = page.draft;
                qsReload.running = true;
                page.status = "Applied";
            } else {
                page.status = page.errorOutput || "Could not apply bar settings";
            }
        }
    }

    Process {
        id: qsReload
        command: ["qs", "ipc", "call", "bar", "reload"]
    }

    component Cols: Grid {
        property int cols: 2
        readonly property real cellWidth: Math.floor((width - (cols - 1) * columnSpacing) / cols)
        width: parent.width
        columns: cols
        columnSpacing: 12
        rowSpacing: 6
    }

    component SectionTitle: Text {
        color: Theme.text
        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSection; font.bold: true; font.letterSpacing: 2
    }

    component GroupLabel: Text {
        color: Theme.accent2
        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; font.bold: true; font.letterSpacing: 1
    }

    component Note: Text {
        width: parent.width
        wrapMode: Text.WordWrap
        color: Theme.textDim
        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSmall
    }

    component Card: Rectangle {
        id: card
        default property alias contentData: cardColumn.data
        width: parent.width
        height: cardColumn.implicitHeight + 20
        radius: Theme.radius
        color: "#00000000"; border.width: 1; border.color: Theme.border

        Column {
            id: cardColumn
            x: 10; y: 10
            width: parent.width - 20
            spacing: 8
        }
    }

    component SmallButton: Rectangle {
        id: sb
        property string label: ""
        property bool current: false
        property bool buttonEnabled: true
        signal clicked()
        height: 26; radius: Theme.radius
        opacity: buttonEnabled ? 1.0 : 0.35
        color: current ? Theme.alpha(Theme.accent, 0.10) : (sbMouse.containsMouse ? Theme.alpha(Theme.accent, 0.08) : "#00000000")
        border.width: 1
        border.color: current || sbMouse.containsMouse ? Theme.accent : Theme.border

        Text {
            anchors.centerIn: parent
            width: Math.min(implicitWidth, sb.width - 8)
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
            text: sb.label
            color: sb.current ? Theme.accent : Theme.text
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody; font.bold: true; font.letterSpacing: 1
        }

        MouseArea {
            id: sbMouse
            anchors.fill: parent; hoverEnabled: true
            enabled: sb.buttonEnabled
            cursorShape: Qt.PointingHandCursor
            onClicked: sb.clicked()
        }
    }

    // Section chip: sized to its text, scrolls the page to `target`.
    // On/off switch as a single button: filled dot + highlight = on.
    component ToggleRow: Item {
        id: tg
        property string label: ""
        property bool checked: false
        signal toggled(bool v)

        width: parent.cellWidth ?? parent.width
        height: 26
        opacity: enabled ? 1.0 : 0.4

        SmallButton {
            width: tg.width; height: tg.height
            label: (tg.checked ? "● " : "○ ") + tg.label
            current: tg.checked
            buttonEnabled: tg.enabled
            onClicked: tg.toggled(!tg.checked)
        }
    }

    // Label + value on one line, drag track right below.
    //   moved     = live value while dragging (only emitted when the value actually changes)
    //   committed = emitted once on release, with the final value (use to persist)
    component BarSlider: Item {
        id: sl
        property string label: ""
        property real from: 0
        property real to: 1
        property real step: 1
        property real value: 0
        property string unit: ""
        property real displayScale: 1
        property int decimals: 0
        property bool dragging: false
        signal moved(real v)
        signal committed(real v)

        readonly property real ratio: to > from ? Math.max(0, Math.min(1, (value - from) / (to - from))) : 0

        width: parent.cellWidth ?? parent.width
        height: 34
        opacity: enabled ? 1.0 : 0.4

        Text {
            anchors.left: parent.left; anchors.right: valueText.left; anchors.rightMargin: 6
            y: 0
            elide: Text.ElideRight
            text: sl.label
            color: Theme.textDim
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody; font.letterSpacing: 1
        }

        Text {
            id: valueText
            anchors.right: parent.right; y: 0
            text: (sl.value * sl.displayScale).toFixed(sl.decimals) + sl.unit
            color: Theme.accent2
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSmall
        }

        Rectangle {
            id: track
            anchors.left: parent.left; anchors.right: parent.right
            y: 24; height: 4; radius: 2
            color: Theme.border

            Rectangle {
                width: knob.x + knob.width / 2
                height: parent.height; radius: 2
                color: Theme.accent
            }
            Rectangle {
                id: knob
                width: 12; height: 12; radius: 6
                anchors.verticalCenter: parent.verticalCenter
                x: sl.ratio * (track.width - width)
                color: Theme.accent
            }
        }

        MouseArea {
            anchors.left: parent.left; anchors.right: parent.right
            y: 14; height: 20
            hoverEnabled: true
            preventStealing: true      // keep the page from scrolling while dragging
            enabled: sl.enabled
            cursorShape: Qt.PointingHandCursor

            function apply(mx) {
                const usable = track.width - knob.width
                if (usable <= 0) return
                const r = Math.max(0, Math.min(1, (mx - knob.width / 2) / usable))
                const raw = sl.from + r * (sl.to - sl.from)
                const v = sl.step > 0 ? +(Math.round(raw / sl.step) * sl.step).toFixed(4) : raw
                if (v !== sl.value) sl.moved(v)
            }
            onPressed: m => { sl.dragging = true; apply(m.x) }
            onPositionChanged: m => { if (pressed) apply(m.x) }
            onReleased: { if (sl.dragging) { sl.dragging = false; sl.committed(sl.value) } }
            onCanceled: sl.dragging = false
        }
    }

    // Label on top, one button per option side by side (wraps after `maxCols`).
    component BarChoice: Item {
        id: ch
        property string label: ""
        property var options: []
        property string current: ""
        property int maxCols: 4
        property var labels: ({})          // optional id → display text (default: id in upper case)
        property var disabledOptions: []   // ids shown dimmed and not clickable
        signal picked(string v)

        readonly property int cols: Math.max(1, Math.min(options.length, maxCols))

        width: parent.cellWidth ?? parent.width
        height: lbl.implicitHeight + 3 + flow.implicitHeight
        opacity: enabled ? 1.0 : 0.4

        Text {
            id: lbl
            text: ch.label
            color: Theme.textDim
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody; font.letterSpacing: 1
        }

        Flow {
            id: flow
            y: lbl.implicitHeight + 3
            width: parent.width
            spacing: 6

            Repeater {
                model: ch.options
                delegate: SmallButton {
                    required property string modelData
                    width: Math.floor((ch.width - (ch.cols - 1) * 6) / ch.cols)
                    label: ch.labels[modelData] ?? modelData.toUpperCase()
                    current: modelData === ch.current
                    buttonEnabled: ch.enabled && ch.disabledOptions.indexOf(modelData) < 0
                    onClicked: ch.picked(modelData)
                }
            }
        }
    }

    ScrollBar.vertical: ScrollBar {
        implicitWidth: 8
        contentItem: Rectangle {
            implicitWidth: 4
            radius: width / 2
            color: Theme.alpha(Theme.accent, 0.3)
        }
    }

    Column {
        width: page.availableWidth - 8
        spacing: 8
        enabled: page.ready && !applyProcess.running

        RowLayout {
            width: parent.width
            spacing: 6
            SectionTitle { text: "WAYBAR"; Layout.fillWidth: true }
            SmallButton {
                width: 74; height: 22; label: "RESET"
                onClicked: {
                    page.draft = JSON.parse(defaultsFile.text());
                    page.status = "";
                }
            }
            SmallButton {
                width: 74; height: 22; label: "APPLY"
                buttonEnabled: page.dirty && page.enabled
                current: buttonEnabled
                onClicked: {
                    page.status = "";
                    page.errorOutput = "";
                    applyProcess.command = ["python3", page.configHome + "/waybar/configure.py",
                                            "apply", JSON.stringify(page.draft)];
                    applyProcess.running = true;
                }
            }
        }

        Note { visible: page.status !== ""; text: page.status }

        Card {
            GroupLabel { text: "LAYOUT & APPEARANCE" }
            Cols {
                BarChoice {
                    label: "POSITION"
                    options: ["top", "bottom"]
                    current: page.draft.position ?? "top"
                    onPicked: value => page.setValue("position", value)
                }
                BarChoice {
                    label: "WORKSPACE LABELS"
                    options: ["kanji", "numbers"]
                    current: page.draft.workspaceLabels ?? "kanji"
                    onPicked: value => page.setValue("workspaceLabels", value)
                }
            }
            Cols {
                BarSlider {
                    label: "SCALE"; from: 0.8; to: 2; step: 0.05; decimals: 2; unit: "×"
                    value: page.draft.scale ?? 1.35
                    onMoved: value => page.setValue("scale", value)
                }
                BarSlider {
                    label: "PANEL OPACITY"; from: 10; to: 100; step: 1; unit: "%"
                    value: page.draft.opacity ?? 70
                    onMoved: value => page.setValue("opacity", value)
                }
                BarSlider {
                    label: "EDGE MARGIN"; from: 0; to: 24; step: 1; unit: " px"
                    value: page.draft.margin ?? 6
                    onMoved: value => page.setValue("margin", value)
                }
                BarSlider {
                    label: "MODULE SPACING"; from: 0; to: 20; step: 1; unit: " px"
                    value: page.draft.spacing ?? 4
                    onMoved: value => page.setValue("spacing", value)
                }
            }
            GroupLabel { text: "TYPE & EFFECTS" }
            Cols {
                BarChoice {
                    label: "FONT WEIGHT"
                    options: ["400", "500", "600", "700"]
                    labels: ({ "400": "REGULAR", "500": "MEDIUM", "600": "SEMIBOLD", "700": "BOLD" })
                    current: String(page.draft.fontWeight ?? 700)
                    onPicked: value => page.setValue("fontWeight", Number(value))
                }
                BarSlider {
                    label: "FONT SIZE"; from: 8; to: 22; step: 1; unit: " px"
                    value: page.draft.fontSize ?? 12
                    onMoved: value => page.setValue("fontSize", value)
                }
                BarSlider {
                    label: "CORNER RADIUS"; from: 0; to: 36; step: 1; unit: " px"
                    value: page.draft.radius ?? 16
                    onMoved: value => page.setValue("radius", value)
                }
                BarSlider {
                    label: "ACCENT TINT"; from: 0; to: 50; step: 1; unit: "%"
                    value: page.draft.tint ?? 34
                    onMoved: value => page.setValue("tint", value)
                }
            }
            ToggleRow {
                label: "BACKGROUND BLUR"
                checked: page.draft.blur ?? false
                onToggled: value => page.setValue("blur", value)
            }
            Cols {
                ToggleRow {
                    label: "RESERVE SPACE"
                    checked: page.draft.reserveSpace ?? true
                    onToggled: value => page.setValue("reserveSpace", value)
                }
                ToggleRow {
                    label: "24-HOUR CLOCK"
                    checked: page.draft.clock24 ?? true
                    onToggled: value => page.setValue("clock24", value)
                }
            }
        }

        SectionTitle { text: "MODULES" }
        Card {
            Repeater {
                model: page.catalog
                RowLayout {
                    id: item
                    required property var modelData
                    readonly property string moduleId: modelData[0]
                    readonly property int location: page.sectionIndex(moduleId)
                    readonly property int order: Number(page.orderLabel(moduleId))
                    width: parent.width
                    spacing: 5

                    Text {
                        Layout.fillWidth: true
                        Layout.minimumWidth: 45
                        text: item.modelData[1].toUpperCase()
                        color: Theme.textDim
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.textSizeBody
                        font.letterSpacing: 1
                        elide: Text.ElideRight
                    }

                    Repeater {
                        model: ["LEFT", "CENTER", "RIGHT", "HIDDEN"]
                        SmallButton {
                            required property int index
                            required property string modelData
                            width: Math.min(66, Math.max(46, item.width * 0.13))
                            height: 22
                            label: modelData
                            current: item.location === index
                            buttonEnabled: !current
                            opacity: 1
                            onClicked: page.putModule(item.moduleId, index)
                        }
                    }

                    Text {
                        Layout.preferredWidth: 16
                        horizontalAlignment: Text.AlignHCenter
                        color: Theme.accent2
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.textSizeSmall
                        text: page.orderLabel(item.moduleId)
                    }
                    SmallButton {
                        width: 23; height: 22; label: "↑"
                        Accessible.name: "Move " + item.modelData[1] + " earlier"
                        buttonEnabled: item.order > 1
                        onClicked: page.moveModule(item.moduleId, -1)
                    }
                    SmallButton {
                        width: 23; height: 22; label: "↓"
                        Accessible.name: "Move " + item.modelData[1] + " later"
                        buttonEnabled: item.location < 3 && item.order < (page.draft[page.sections[item.location]] ?? []).length
                        onClicked: page.moveModule(item.moduleId, 1)
                    }
                }
            }
        }
    }
}
