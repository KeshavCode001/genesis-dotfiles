import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: calendar
    signal closeRequested()
    property date monthDate: new Date()

    radius: 18
    color: Qt.alpha(Colors.primaryContainer, 0.82)
    border.color: Qt.alpha(Colors.primary, 0.6)

    function moveMonth(offset) {
        monthDate = new Date(monthDate.getFullYear(), monthDate.getMonth() + offset, 1);
    }

    component CalendarButton: Button {
        id: pill
        implicitWidth: 31
        implicitHeight: 28
        background: Rectangle {
            radius: height / 2
            color: pill.hovered ? Qt.alpha(Colors.primary, 0.28) : Colors.glass
            border.color: Qt.alpha(Colors.primary, 0.42)
        }
        contentItem: Text {
            text: pill.text
            color: Colors.textOnSurface
            font.family: Theme.font.family
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Math.max(7, Math.min(15, calendar.width / 22))
        spacing: 5

        RowLayout {
            Layout.fillWidth: true
            CalendarButton { text: "‹"; Accessible.name: "Previous month"; onClicked: calendar.moveMonth(-1) }
            Text {
                Layout.fillWidth: true
                text: Qt.formatDate(calendar.monthDate, "MMM yyyy")
                color: Colors.textOnSurface
                font.family: Theme.font.family
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideRight
            }
            CalendarButton { text: "›"; Accessible.name: "Next month"; onClicked: calendar.moveMonth(1) }
            CalendarButton { text: "×"; Accessible.name: "Close calendar"; onClicked: calendar.closeRequested() }
        }

        DayOfWeekRow {
            Layout.fillWidth: true
            locale: grid.locale
            delegate: Text {
                required property var model
                text: model.shortName
                color: Colors.primary
                font.family: Theme.font.family
                font.pixelSize: 10
                horizontalAlignment: Text.AlignHCenter
            }
        }

        MonthGrid {
            id: grid
            Layout.fillWidth: true
            Layout.fillHeight: true
            month: calendar.monthDate.getMonth()
            year: calendar.monthDate.getFullYear()
            delegate: Rectangle {
                required property var model
                readonly property bool currentDay: model.today
                radius: width / 2
                color: currentDay ? Qt.alpha(Colors.primary, 0.3) : "transparent"
                Text {
                    anchors.centerIn: parent
                    text: parent.model.day
                    color: Colors.textOnSurface
                    opacity: parent.model.month === grid.month ? 1 : 0.38
                    font.family: Theme.font.family
                    font.bold: parent.currentDay
                    font.pixelSize: 12
                }
            }
        }
    }
}
