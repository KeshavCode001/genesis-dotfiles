import QtQuick

Item {
    id: transition
    required property bool active
    required property color accent

    visible: active
    opacity: active ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: 160 } }

    Rectangle {
        anchors.fill: parent
        color: "#d1111320"
    }

    Item {
        id: planet
        anchors.centerIn: parent
        width: 170
        height: width
        opacity: 0
        scale: 0.84

        Item {
            id: orbit
            anchors.fill: parent
            Repeater {
                model: 28
                Rectangle {
                    required property int index
                    readonly property real angle: index * 2 * Math.PI / 28
                    width: index % 4 === 0 ? 5 : 3
                    height: width
                    radius: width / 2
                    x: orbit.width / 2 + Math.cos(angle) * (70 + index % 3 * 11)
                    y: orbit.height / 2 + Math.sin(angle) * (54 + index % 3 * 7)
                    color: transition.accent
                    opacity: 0.35 + index % 5 * 0.12
                }
            }
        }

        Rectangle {
            anchors.centerIn: parent
            width: 94
            height: width
            radius: width / 2
            color: "#ea141622"
            border.color: transition.accent

            Rectangle {
                x: 34
                y: 27
                width: 26
                height: 25
                radius: 10
                color: "transparent"
                border.width: 3
                border.color: transition.accent
            }
            Rectangle {
                x: 30
                y: 42
                width: 34
                height: 25
                radius: 5
                color: transition.accent
                Rectangle {
                    anchors.centerIn: parent
                    width: 5
                    height: 8
                    radius: 3
                    color: "#141622"
                }
            }
        }
    }

    SequentialAnimation {
        running: transition.active
        ParallelAnimation {
            NumberAnimation { target: planet; property: "opacity"; from: 0; to: 1; duration: 200 }
            NumberAnimation { target: planet; property: "scale"; from: 0.84; to: 1; duration: 220; easing.type: Easing.OutCubic }
        }
        PauseAnimation { duration: 185 }
        ParallelAnimation {
            NumberAnimation { target: planet; property: "opacity"; to: 0; duration: 260; easing.type: Easing.InOutQuad }
            NumberAnimation { target: planet; property: "scale"; to: 1.13; duration: 260; easing.type: Easing.InOutQuad }
        }
    }
    NumberAnimation {
        target: orbit
        property: "rotation"
        from: 0
        to: 130
        duration: 665
        easing.type: Easing.InOutCubic
        running: transition.active
    }

    MouseArea { anchors.fill: parent; onWheel: wheel => wheel.accepted = true }
}
