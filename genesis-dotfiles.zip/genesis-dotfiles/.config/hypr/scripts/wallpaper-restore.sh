#!/usr/bin/env bash
# Draw the wallpaper recorded by theme.py (set by the installer or the picker).
state="${XDG_STATE_HOME:-$HOME/.local/state}/43pr/state.json"

img="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("wallpaper",""))' "$state" 2>/dev/null)"
[[ -f "$img" ]] || exit 0

# Wait for the awww daemon to be ready (up to ~5s)
for _ in {1..20}; do
    awww query >/dev/null 2>&1 && break
    sleep 0.25
done

if awww img "$img" -t none; then
    cache="$HOME/.cache/43pr"
    mkdir -p "$cache"
    if [[ "$(readlink -f "$cache/rofi-wallpaper")" != "$(realpath -- "$img")" ]] ||
       [[ ! -r "$cache/rofi-glass.rasi" || ! -r "$cache/rofi-glass-picker.rasi" ]]; then
        ln -sfn -- "$(realpath -- "$img")" "$cache/rofi-wallpaper"
        bash "$HOME/.config/hypr/scripts/rofi-glass-preview.sh"
    fi
    bash "$HOME/.config/hypr/scripts/sddm-wallpaper.sh" "$img"
fi
